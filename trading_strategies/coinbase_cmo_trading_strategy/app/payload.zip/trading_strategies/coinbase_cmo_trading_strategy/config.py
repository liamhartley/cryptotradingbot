LOGICAL_PARAMS = {
    "CMO_PERIOD": 7,
    "PERIOD": 21600,
    "PAIR": "ETH-USDC",
    "OVERSOLD_VALUE": -39,
    "OVERBOUGHT_VALUE": 39,
    "DRY_RUN": False,
    "INITIAL_CAPITAL": 105,  # in quote currency # TODO
    "ENTRY_SIZE": 0.1  # 10%
}
